gdjs.PORTAL_32FOQUETECode = {};
gdjs.PORTAL_32FOQUETECode.localVariables = [];


gdjs.PORTAL_32FOQUETECode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TEMPO DO PORTAL");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TEMPO DO PORTAL") >= 3;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "FOQUETE", false);
}}

}


};

gdjs.PORTAL_32FOQUETECode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.PORTAL_32FOQUETECode.eventsList0(runtimeScene);


return;

}

gdjs['PORTAL_32FOQUETECode'] = gdjs.PORTAL_32FOQUETECode;
