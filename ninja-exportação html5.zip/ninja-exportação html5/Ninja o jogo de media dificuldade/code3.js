gdjs.FOQUETECode = {};
gdjs.FOQUETECode.localVariables = [];
gdjs.FOQUETECode.GDFOQUETEObjects1= [];
gdjs.FOQUETECode.GDFOQUETEObjects2= [];
gdjs.FOQUETECode.GDBASEObjects1= [];
gdjs.FOQUETECode.GDBASEObjects2= [];
gdjs.FOQUETECode.GDLUAObjects1= [];
gdjs.FOQUETECode.GDLUAObjects2= [];
gdjs.FOQUETECode.GDRedExplosionObjects1= [];
gdjs.FOQUETECode.GDRedExplosionObjects2= [];


gdjs.FOQUETECode.mapOfGDgdjs_9546FOQUETECode_9546GDRedExplosionObjects1Objects = Hashtable.newFrom({"RedExplosion": gdjs.FOQUETECode.GDRedExplosionObjects1});
gdjs.FOQUETECode.mapOfGDgdjs_9546FOQUETECode_9546GDLUAObjects1Objects = Hashtable.newFrom({"LUA": gdjs.FOQUETECode.GDLUAObjects1});
gdjs.FOQUETECode.mapOfGDgdjs_9546FOQUETECode_9546GDFOQUETEObjects1Objects = Hashtable.newFrom({"FOQUETE": gdjs.FOQUETECode.GDFOQUETEObjects1});
gdjs.FOQUETECode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
gdjs.FOQUETECode.GDRedExplosionObjects1.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TEMPO DE PARTIDA 1");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.FOQUETECode.mapOfGDgdjs_9546FOQUETECode_9546GDRedExplosionObjects1Objects, 426, 541, "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TEMPO PARA DECOLAR");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TEMPO DE PARTIDA 1") >= 5;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BASE"), gdjs.FOQUETECode.GDBASEObjects1);
gdjs.FOQUETECode.GDLUAObjects1.length = 0;

{for(var i = 0, len = gdjs.FOQUETECode.GDBASEObjects1.length ;i < len;++i) {
    gdjs.FOQUETECode.GDBASEObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.FOQUETECode.mapOfGDgdjs_9546FOQUETECode_9546GDLUAObjects1Objects, -(30), -(4), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TEMPO DE PARTIDA 1") >= 7;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FOQUETE"), gdjs.FOQUETECode.GDFOQUETEObjects1);
{for(var i = 0, len = gdjs.FOQUETECode.GDFOQUETEObjects1.length ;i < len;++i) {
    gdjs.FOQUETECode.GDFOQUETEObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.FOQUETECode.mapOfGDgdjs_9546FOQUETECode_9546GDFOQUETEObjects1Objects, 279, -(321), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TEMPO DE PARTIDA 1");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TEMPO PARA DECOLAR");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TEMPO PARA DECOLAR") >= 5;
if (isConditionTrue_0) {
}

}


};

gdjs.FOQUETECode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.FOQUETECode.GDFOQUETEObjects1.length = 0;
gdjs.FOQUETECode.GDFOQUETEObjects2.length = 0;
gdjs.FOQUETECode.GDBASEObjects1.length = 0;
gdjs.FOQUETECode.GDBASEObjects2.length = 0;
gdjs.FOQUETECode.GDLUAObjects1.length = 0;
gdjs.FOQUETECode.GDLUAObjects2.length = 0;
gdjs.FOQUETECode.GDRedExplosionObjects1.length = 0;
gdjs.FOQUETECode.GDRedExplosionObjects2.length = 0;

gdjs.FOQUETECode.eventsList0(runtimeScene);
gdjs.FOQUETECode.GDFOQUETEObjects1.length = 0;
gdjs.FOQUETECode.GDFOQUETEObjects2.length = 0;
gdjs.FOQUETECode.GDBASEObjects1.length = 0;
gdjs.FOQUETECode.GDBASEObjects2.length = 0;
gdjs.FOQUETECode.GDLUAObjects1.length = 0;
gdjs.FOQUETECode.GDLUAObjects2.length = 0;
gdjs.FOQUETECode.GDRedExplosionObjects1.length = 0;
gdjs.FOQUETECode.GDRedExplosionObjects2.length = 0;


return;

}

gdjs['FOQUETECode'] = gdjs.FOQUETECode;
