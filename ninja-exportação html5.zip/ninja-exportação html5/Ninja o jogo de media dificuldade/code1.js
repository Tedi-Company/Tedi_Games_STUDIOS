gdjs.GameCode = {};
gdjs.GameCode.localVariables = [];
gdjs.GameCode.GDPijamondataC_9595windowsObjects1= [];
gdjs.GameCode.GDPijamondataC_9595windowsObjects2= [];
gdjs.GameCode.GDplataformaObjects1= [];
gdjs.GameCode.GDplataformaObjects2= [];
gdjs.GameCode.GDNewTiledSpriteObjects1= [];
gdjs.GameCode.GDNewTiledSpriteObjects2= [];
gdjs.GameCode.GDPORTAL_9595FOQUETEObjects1= [];
gdjs.GameCode.GDPORTAL_9595FOQUETEObjects2= [];


gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDNewTiledSpriteObjects1Objects = Hashtable.newFrom({"NewTiledSprite": gdjs.GameCode.GDNewTiledSpriteObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPijamondataC_95959595windowsObjects1Objects = Hashtable.newFrom({"PijamondataC_windows": gdjs.GameCode.GDPijamondataC_9595windowsObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPijamondataC_95959595windowsObjects1Objects = Hashtable.newFrom({"PijamondataC_windows": gdjs.GameCode.GDPijamondataC_9595windowsObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPORTAL_95959595FOQUETEObjects1Objects = Hashtable.newFrom({"PORTAL_FOQUETE": gdjs.GameCode.GDPORTAL_9595FOQUETEObjects1});
gdjs.GameCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("PijamondataC_windows"), gdjs.GameCode.GDPijamondataC_9595windowsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPijamondataC_9595windowsObjects1[k] = gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPijamondataC_9595windowsObjects1[k] = gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPijamondataC_9595windowsObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i].getBehavior("Animation").setAnimationName("parado");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PijamondataC_windows"), gdjs.GameCode.GDPijamondataC_9595windowsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPijamondataC_9595windowsObjects1[k] = gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPijamondataC_9595windowsObjects1[k] = gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPijamondataC_9595windowsObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i].getBehavior("Animation").setAnimationName("corendo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PijamondataC_windows"), gdjs.GameCode.GDPijamondataC_9595windowsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPijamondataC_9595windowsObjects1[k] = gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPijamondataC_9595windowsObjects1[k] = gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPijamondataC_9595windowsObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i].getBehavior("Animation").setAnimationName("pulando");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PijamondataC_windows"), gdjs.GameCode.GDPijamondataC_9595windowsObjects1);
{for(var i = 0, len = gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i].getBehavior("Flippable").flipX(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PijamondataC_windows"), gdjs.GameCode.GDPijamondataC_9595windowsObjects1);
{for(var i = 0, len = gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i].getBehavior("Flippable").flipX(true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "bacToMenu");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite"), gdjs.GameCode.GDNewTiledSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("PijamondataC_windows"), gdjs.GameCode.GDPijamondataC_9595windowsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDNewTiledSpriteObjects1Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPijamondataC_95959595windowsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPijamondataC_9595windowsObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPijamondataC_9595windowsObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PORTAL_FOQUETE"), gdjs.GameCode.GDPORTAL_9595FOQUETEObjects1);
gdjs.copyArray(runtimeScene.getObjects("PijamondataC_windows"), gdjs.GameCode.GDPijamondataC_9595windowsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPijamondataC_95959595windowsObjects1Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPORTAL_95959595FOQUETEObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "PORTAL FOQUETE");
}}

}


};

gdjs.GameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length = 0;
gdjs.GameCode.GDPijamondataC_9595windowsObjects2.length = 0;
gdjs.GameCode.GDplataformaObjects1.length = 0;
gdjs.GameCode.GDplataformaObjects2.length = 0;
gdjs.GameCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.GameCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.GameCode.GDPORTAL_9595FOQUETEObjects1.length = 0;
gdjs.GameCode.GDPORTAL_9595FOQUETEObjects2.length = 0;

gdjs.GameCode.eventsList0(runtimeScene);
gdjs.GameCode.GDPijamondataC_9595windowsObjects1.length = 0;
gdjs.GameCode.GDPijamondataC_9595windowsObjects2.length = 0;
gdjs.GameCode.GDplataformaObjects1.length = 0;
gdjs.GameCode.GDplataformaObjects2.length = 0;
gdjs.GameCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.GameCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.GameCode.GDPORTAL_9595FOQUETEObjects1.length = 0;
gdjs.GameCode.GDPORTAL_9595FOQUETEObjects2.length = 0;


return;

}

gdjs['GameCode'] = gdjs.GameCode;
