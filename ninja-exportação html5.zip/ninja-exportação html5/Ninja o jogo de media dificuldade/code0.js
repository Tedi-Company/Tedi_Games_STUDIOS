gdjs.MenuCode = {};
gdjs.MenuCode.localVariables = [];
gdjs.MenuCode.GDBackgroundObjects1= [];
gdjs.MenuCode.GDBackgroundObjects2= [];
gdjs.MenuCode.GDTitleObjects1= [];
gdjs.MenuCode.GDTitleObjects2= [];
gdjs.MenuCode.GDButton_9595PlayObjects1= [];
gdjs.MenuCode.GDButton_9595PlayObjects2= [];
gdjs.MenuCode.GDButton_9595QuitObjects1= [];
gdjs.MenuCode.GDButton_9595QuitObjects2= [];


gdjs.MenuCode.mapOfGDgdjs_9546MenuCode_9546GDButton_95959595PlayObjects1Objects = Hashtable.newFrom({"Button_Play": gdjs.MenuCode.GDButton_9595PlayObjects1});
gdjs.MenuCode.mapOfGDgdjs_9546MenuCode_9546GDButton_95959595QuitObjects1Objects = Hashtable.newFrom({"Button_Quit": gdjs.MenuCode.GDButton_9595QuitObjects1});
gdjs.MenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Button_Play"), gdjs.MenuCode.GDButton_9595PlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_9546MenuCode_9546GDButton_95959595PlayObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button_Quit"), gdjs.MenuCode.GDButton_9595QuitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_9546MenuCode_9546GDButton_95959595QuitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.window.setFullScreen(runtimeScene, true, true);
}}

}


};

gdjs.MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MenuCode.GDBackgroundObjects1.length = 0;
gdjs.MenuCode.GDBackgroundObjects2.length = 0;
gdjs.MenuCode.GDTitleObjects1.length = 0;
gdjs.MenuCode.GDTitleObjects2.length = 0;
gdjs.MenuCode.GDButton_9595PlayObjects1.length = 0;
gdjs.MenuCode.GDButton_9595PlayObjects2.length = 0;
gdjs.MenuCode.GDButton_9595QuitObjects1.length = 0;
gdjs.MenuCode.GDButton_9595QuitObjects2.length = 0;

gdjs.MenuCode.eventsList0(runtimeScene);
gdjs.MenuCode.GDBackgroundObjects1.length = 0;
gdjs.MenuCode.GDBackgroundObjects2.length = 0;
gdjs.MenuCode.GDTitleObjects1.length = 0;
gdjs.MenuCode.GDTitleObjects2.length = 0;
gdjs.MenuCode.GDButton_9595PlayObjects1.length = 0;
gdjs.MenuCode.GDButton_9595PlayObjects2.length = 0;
gdjs.MenuCode.GDButton_9595QuitObjects1.length = 0;
gdjs.MenuCode.GDButton_9595QuitObjects2.length = 0;


return;

}

gdjs['MenuCode'] = gdjs.MenuCode;
